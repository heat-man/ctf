from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

def xor(a: bytes, b: bytes) -> bytes:
    return bytes([x^y for x,y in zip(a,b)])

class AES_ACBC:
    def __init__(self, key: bytes, iv: bytes) -> None:
        assert len(key) == 16
        assert len(iv) == 16
        self.iv = iv
        self.cipher = AES.new(key, AES.MODE_ECB)

    def encrypt(self, plaintext: bytes) -> tuple[bool, bytes]:
        try:
            padded = pad(plaintext, 16)
            ciphertext = b''
            iv = self.iv
            for i in range(0, len(padded), 16):
                cur_block = padded[i:i+16]
                enc_block = xor(cur_block, iv)
                enc_block = self.cipher.encrypt(enc_block)
                enc_block = xor(enc_block, iv)
                ciphertext += enc_block
                iv = enc_block
            return True, ciphertext
        except ValueError:
            return False, b''

    def decrypt(self, ciphertext: bytes) -> tuple[bool, bytes]:
        try:
            padded = b''
            iv = self.iv
            for i in range(0, len(ciphertext), 16):
                cur_block = ciphertext[i:i+16]
                dec_block = xor(cur_block, iv)
                dec_block = self.cipher.decrypt(dec_block)
                dec_block = xor(dec_block, iv)
                padded += dec_block
                iv = cur_block
            plaintext = unpad(padded, 16)
            return True, plaintext
        except ValueError:
            return False, b''

if __name__ == '__main__':
    import os

    for _ in range(0x1000):
        key = os.urandom(16)
        iv = os.urandom(16)

        aes = AES_ACBC(key, iv)

        pt = os.urandom(16)
        ct = aes.encrypt(pt)[1]
        print(f'{pt.hex() = }')
        print(f'{ct.hex() = }')
        assert pt == aes.decrypt(ct)[1]
