#!/usr/bin/env python3
import os
from cipher import AES_ACBC

def menu() -> int:
    print('1. encrypt')
    print('2. decrypt')
    print('3. flag')
    print('4. exit')
    return int(input('> '))

def redact_block(target:bytes) -> bytes:
    if len(target) < 16:
        return b'[** REDACTED **]'
    return b'[** REDACTED **]' * (len(target)//16)

if __name__ == '__main__':
    with open('flag', 'rb') as f:
        flag = f.read()

    key = os.urandom(16)
    iv = os.urandom(16)
    aes = AES_ACBC(key,iv)

    print(f'IV: {iv.hex()}')

    while True:
        i = menu()
        if i == 1:
            msg = input('plaintext(hex)> ')
            success, enc = aes.encrypt(bytes.fromhex(msg))
            if success:
                print(f'ciphertext(hex)> {enc.hex()}')
            else:
                print('[error] encryption failed')
        elif i == 2:
            enc = input('ciphertext(hex)> ')
            success, dec = aes.decrypt(bytes.fromhex(enc))
            if success:
                dec = redact_block(dec)
                print(f'decrypted(hex)> {dec}')
            else:
                print('[error] decryption failed')
        elif i == 3:
            success, enc_flag = aes.encrypt(flag)
            if success:
                print(f'encrypted flag(hex)> {enc_flag.hex()}')
            else:
                print('[error] encryption failed')
        elif i == 4:
            print('bye~')
            exit()
        else:
            print('[error] invalid option')
